import { Box, Card, Grid, InlineGrid, InlineStack, Page, Select, Text, TextField, Tooltip } from '@shopify/polaris';
import React, { useCallback, useState,useContext } from 'react';
import BannerContext from './bannercontext';
import ReactSwitch from 'react-switch';

export default function Countdownsetup() {

    const context = useContext(BannerContext);

      const {
                selectenddate,setSelectenddate,dateTime,setDateTime,days,setDays,hours,setHours,minutes,setMinutes,selectedplace,
                setSelectedplace,dayslbl,setDayslbl,hourslbl,setHourslbl,minuteslbl,setMinuteslbl,secondslbl,setSecondslbl,
                digitColor,setDigitColor,labelColor,setLabelColor,backgroundColor,setBackgroundColor,labelgap,setLabelgap,
                countdisplay,setCountdisplay,specificdate,setSpecificdate,startDate,setStartDate,endDate,setEndDate,
     } = context;


     const handleSelectday = useCallback((value) => {
        if (value === '' || Number(value) >= 0) {
            setDays(value);
        }
    }, []);

     const handleSelecthours = useCallback((value) => {
        if (value === '' || Number(value) >= 0) {
            setHours(value);
        }
    }, []);

     const handleSelectminutes = useCallback((value) => {
        if (value === '' || Number(value) >= 0) {
            setMinutes(value);
        }
    }, []);
    const handleSelectChange = useCallback(
        (value) => setSelectenddate(value),
        [],
    );
     const handleChange = (newValue) => {
        setDateTime(newValue);
    };
    const handlespcificdate = (newValue) => {
        setSpecificdate(newValue);
    };

    const options = [
        {label: 'Specific dates', value: 'specific dates'},
        {label: 'Till End Date', value: 'till end date'},
        {label: 'Duration', value: 'duration'},
    ];

    const handleSelectplace = useCallback(
        (value) => setSelectedplace(value),
        [],
    );

    const place = [
    {label: 'Left', value: 'left'},
    {label: 'Right', value: 'right'},
  ];

  const handlecountdisplay = useCallback(
        (newChecked) => setCountdisplay(newChecked),
        [],
    );

  const handleChangeDayslbl = useCallback((value) => {
      setDayslbl(value);
  }, []);

  const handleChangeHourslbl = useCallback((value) => {
      setHourslbl(value);
  }, []);

  const handleChangeMinuteslbl = useCallback((value) => {
      setMinuteslbl(value);
  }, []);

  const handleChangeSecondslbl = useCallback((value) => {
      setSecondslbl(value);
  }, []);

   const handleDigitColorChange = useCallback((value) => setDigitColor(value), []);
  const handleLabelColorChange = useCallback((value) => setLabelColor(value), []);
  const handleBackgroundColorChange = useCallback((value) => setBackgroundColor(value), []);


   const handleSelectlabelgap = useCallback(
    (value) => setLabelgap(value),
    [],
  );

  
   const labelgapchange = [
    {label: 'None', value: 'none'},
    {label: 'Small', value: 'small'},
    {label: 'Medium', value: 'medium'},
    {label: 'Large', value: 'large'},
    {label: 'Extra Large', value: 'extra large'},
  ];

  
  return (
        <Card>
            <Grid>
                <Grid.Cell columnSpan={{xs: 6, sm: 3, md: 3, lg: 6, xl: 6}}>
                    <InlineStack gap="400" wrap={false}>
                        <Box width="250px" >
                            <Select
                                label="Date range"
                                options={options}
                                onChange={handleSelectChange}
                                value={selectenddate}
                            /></Box>
                        <Box width="250px" paddingBlock={600}>
                          <InlineStack align="center" gap="100">
                            <Tooltip content="Show a timer counting down to the end of the event.">
                            <Text>Show Countdown Timer</Text></Tooltip>
                                <ReactSwitch
                                    checked={countdisplay}
                                    onChange={handlecountdisplay}
                                    checkedIcon={false}
                                    uncheckedIcon={false}
                                />
                           </InlineStack></Box>
                    </InlineStack>
                    <Box paddingBlock={600}/>
                    <InlineGrid columns={2} gap="200">
                    <Select
                            label="Countdown Placement"
                            options={place}
                            onChange={handleSelectplace}
                            value={selectedplace}
                    />
                    <Select
                            label="Label Gap"
                            options={labelgapchange}
                            onChange={handleSelectlabelgap}
                            value={labelgap}
                      />
                    </InlineGrid>

                </Grid.Cell>
                <Grid.Cell columnSpan={{xs: 6, sm: 3, md: 3, lg: 6, xl: 6}}>

                      {selectenddate === "specific dates" && (
                        <>
                          <Box width="400px" paddingBlock={300}/>
                          <Tooltip content="Only the date/time you choose will be counted for the countdown.">
                             <TextField type="datetime-local" value={specificdate} onChange={handlespcificdate} /></Tooltip>
                         </>
                      )}

                      {selectenddate === "till end date" && (
                        <>
                             <Box width="400px" paddingBlock={300}  >
                               <Tooltip content="Choose the date and time the countdown will end">
                                 <TextField type="datetime-local" value={dateTime} onChange={handleChange} /></Tooltip>
                             </Box>
                         </>
                      )}
                      
                      {selectenddate === "duration" && (
                            <InlineGrid columns={2} gap="200">
                                <Tooltip content="Set the date and time to begin the countdown">
                                                      <TextField type="datetime-local" label="Start Date (Your Local Time)" value={startDate}
                                                           onChange={(value) => setStartDate(value)}/></Tooltip>
                                
                                                     <Tooltip content="Select the date and time when the countdown ends">
                                                        <TextField type="datetime-local" label="End Date (Your Local Time)" value={endDate}
                                                            onChange={(value) => setEndDate(value)}/></Tooltip>
                                {/* <TextField type="number" label="Days" onChange={handleSelectday} value={days}/>
                                <TextField type="number" label="Hours" onChange={handleSelecthours} value={hours}/>
                                <TextField type='number' label="Minutes" onChange={handleSelectminutes} value={minutes}/> */}
                            </InlineGrid>
                      )}

                      <Box paddingBlock={300}/>
                      {/* <Text variant="headingSm" as="h6">
                        Timer Labels
                    </Text>
                      <InlineGrid columns={4} gap="200">
                        <TextField  placeholder='Days'  value={dayslbl} onChange={handleChangeDayslbl}/>
                        <TextField  placeholder='Hours' value={hourslbl} onChange={handleChangeHourslbl}/>
                        <TextField  placeholder='Minutes' value={minuteslbl} onChange={handleChangeMinuteslbl}/>
                        <TextField  placeholder='Seconds' value={secondslbl} onChange={handleChangeSecondslbl}/>
                    </InlineGrid > */}
                    <Text variant="headingSm" as="h6">
                        Timer Colors
                    </Text>
                    <Box padding={300}/>
                    <InlineGrid columns={3} gap="200">
                        <Tooltip content="Select a color to apply to the digits">
                          <TextField type="color" label="Digit Color" value={digitColor} onChange={handleDigitColorChange}/>
                        </Tooltip>
                        <Tooltip content="Select a color to apply to the label">
                          <TextField type="color" label="Label Color" value={labelColor} onChange={handleLabelColorChange}/>
                        </Tooltip>
                        <Tooltip content="Select a color to apply to the digits background">
                          <TextField type="color" label="Background Color" value={backgroundColor} onChange={handleBackgroundColorChange}/>
                        </Tooltip>
                    </InlineGrid> 
                </Grid.Cell>
            </Grid>


        </Card>
  )
}
