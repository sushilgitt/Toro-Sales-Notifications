import { Box, Card, Checkbox, Grid, InlineGrid, Select, Text, TextField, Tooltip } from '@shopify/polaris'
import React, { useCallback, useContext, useState } from 'react'
import BannerContext from './bannercontext';

export default function Visibility() {
    const context = useContext(BannerContext);

    const {
                bannerpos,setBannerpos,closebtn,setClosebtn,
                startDate,setStartDate,endDate,
                setEndDate,show,setShow,hide,
                setHide,sticky,setSticky,
                days,setDays,hours,
                setHours,minutes,setMinutes,
     } = context;

     const handleSelectday = useCallback((value) => {
            if (value === '' || Number(value) >= 0) {
                setDays(value);
            }
        }, []);
    
         const handleSelecthours = useCallback((value) => {
            if (value === '' || Number(value) >= 0) {
                setHours(value);
            }
        }, []);
    
         const handleSelectminutes = useCallback((value) => {
            if (value === '' || Number(value) >= 0) {
                setMinutes(value);
            }
        }, []);

    const handlebannerpos = useCallback(
        (value) => setBannerpos(value),
        [],
    );

    const banner = [
        {label: 'Top', value: 'top'},
        {label: 'Bottom', value: 'bottom'},
    ];

    const handleclosebtn = useCallback(
        (newChecked) => setClosebtn(newChecked),
        [],
    );

    const handleshow = useCallback(
        (value) => setShow(value),
        [],
    );

    const showoptions = [
        {label: '0 Seconds', value: '0 seconds'},
        {label: '2 Seconds', value: '2 seconds'},
        {label: '5 Seconds', value: '5 seconds'},
        {label: '10 Seconds', value: '10 seconds'},
        {label: '15 Seconds', value: '15 seconds'},
        {label: '20 Seconds', value: '20 seconds'},
    ];

    const handlehide = useCallback(
        (value) => setHide(value),
        [],
    );

    const hideoptions = [
        {label: '0 Seconds', value: '0 seconds'},
        {label: '2 Seconds', value: '2 seconds'},
        {label: '5 Seconds', value: '5 seconds'},
        {label: '10 Seconds', value: '10 seconds'},
        {label: '20 Seconds', value: '20 seconds'},
        {label: '30 Seconds', value: '30 seconds'},
        {label: '40 Seconds', value: '40 seconds'},
        {label: '50 Seconds', value: '50 seconds'},
        {label: '60 Seconds', value: '60 seconds'},
    ];

    const handlestickybtn = useCallback(
        (newChecked) => setSticky(newChecked),
        [],
    );

  return (
    <Card>
          <Text variant="headingSm" as="h6">
                Content Visibility
          </Text>
           <Box  paddingBlock={200}/>
          <Grid>
                <Grid.Cell columnSpan={{xs: 6, sm: 3, md: 3, lg: 6, xl: 6}}>
                    <Tooltip content="Set the banner to display at the top or bottom.">
                    <Select
                        label="Banner Position"
                        options={banner}
                        onChange={handlebannerpos}
                        value={bannerpos}
                    /></Tooltip>
                </Grid.Cell>
                <Grid.Cell columnSpan={{xs: 6, sm: 3, md: 3, lg: 6, xl: 6}}>
                        <Checkbox
                            label="Hide Close Button"
                            checked={closebtn}
                            onChange={handleclosebtn}
                            helpText="Hide the 'X' button to prevent users from closing the banner."
                        />
                        <Checkbox
                            label="Sticky Bar"
                            checked={sticky}
                            onChange={handlestickybtn}
                            helpText="Always visible while scrolling"
                        />
                </Grid.Cell>
          </Grid>



           <Box  paddingBlock={100}/>
            <Text variant="headingSm" as="h6">
                   Visibility Duration
            </Text>
            <Box  paddingBlock={200}/>

           <InlineGrid columns={5} gap="300">
                    {/* <Tooltip content="Set the date and time to begin the countdown">
                      <TextField type="datetime-local" label="Start Date (Your Local Time)" value={startDate}
                           onChange={(value) => setStartDate(value)}/></Tooltip>

                     <Tooltip content="Select the date and time when the countdown ends">
                        <TextField type="datetime-local" label="End Date (Your Local Time)" value={endDate}
                            onChange={(value) => setEndDate(value)}/></Tooltip> */}
                            <Tooltip content="Countdown will use only this number of days.">
                               <TextField type="number" label="Days" onChange={handleSelectday} value={days}/>
                            </Tooltip>
                            <Tooltip content="Countdown will use only these hours.">
                               <TextField type="number" label="Hours" onChange={handleSelecthours} value={hours}/>
                            </Tooltip>
                            <Tooltip content="Countdown will use only these minutes.">
                                <TextField type='number' label="Minutes" onChange={handleSelectminutes} value={minutes}/>
                            </Tooltip>

                    <Tooltip content="Select how many seconds to wait before showing the banner.">
                        <Select
                            label="Show after (in seconds)"
                            options={showoptions}
                            onChange={handleshow}
                            value={show}
                        /></Tooltip>

                     <Tooltip content="Set the number of seconds until the banner hides itself.">
                        <Select
                            label="Hide after (in seconds)"
                            options={hideoptions}
                            onChange={handlehide}
                            value={hide}
                       /></Tooltip>
          </InlineGrid>
    </Card>
  )
}
